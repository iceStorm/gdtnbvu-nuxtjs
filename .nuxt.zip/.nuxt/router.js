import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _d0c2d904 = () => interopDefault(import('../pages/about.vue' /* webpackChunkName: "pages/about" */))
const _2cc48051 = () => interopDefault(import('../pages/contact.vue' /* webpackChunkName: "pages/contact" */))
const _9153237a = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))
const _ab8e2afa = () => interopDefault(import('../pages/gallery.vue' /* webpackChunkName: "pages/gallery" */))
const _7ddf00ca = () => interopDefault(import('../pages/members.vue' /* webpackChunkName: "pages/members" */))
const _c707a532 = () => interopDefault(import('../pages/ranking.vue' /* webpackChunkName: "pages/ranking" */))
const _0a67c9e4 = () => interopDefault(import('../pages/news/p/_slug.vue' /* webpackChunkName: "pages/news/p/_slug" */))
const _18b9d8ad = () => interopDefault(import('../pages/news/_slug.vue' /* webpackChunkName: "pages/news/_slug" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _d0c2d904,
    name: "about___vi"
  }, {
    path: "/contact",
    component: _2cc48051,
    name: "contact___vi"
  }, {
    path: "/en",
    component: _9153237a,
    name: "index___en"
  }, {
    path: "/gallery",
    component: _ab8e2afa,
    name: "gallery___vi"
  }, {
    path: "/members",
    component: _7ddf00ca,
    name: "members___vi"
  }, {
    path: "/ranking",
    component: _c707a532,
    name: "ranking___vi"
  }, {
    path: "/en/about",
    component: _d0c2d904,
    name: "about___en"
  }, {
    path: "/en/contact",
    component: _2cc48051,
    name: "contact___en"
  }, {
    path: "/en/gallery",
    component: _ab8e2afa,
    name: "gallery___en"
  }, {
    path: "/en/members",
    component: _7ddf00ca,
    name: "members___en"
  }, {
    path: "/en/ranking",
    component: _c707a532,
    name: "ranking___en"
  }, {
    path: "/en/news/p/:slug?",
    component: _0a67c9e4,
    name: "news-p-slug___en"
  }, {
    path: "/en/news/:slug?",
    component: _18b9d8ad,
    name: "news-slug___en"
  }, {
    path: "/news/p/:slug?",
    component: _0a67c9e4,
    name: "news-p-slug___vi"
  }, {
    path: "/news/:slug?",
    component: _18b9d8ad,
    name: "news-slug___vi"
  }, {
    path: "/",
    component: _9153237a,
    name: "index___vi"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
